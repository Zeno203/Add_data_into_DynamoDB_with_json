﻿from asyncio.windows_events import NULL
from lib2to3.pytree import convert
from time import sleep
from types import DynamicClassAttribute
from venv import create
import boto3
from boto3 import session
import json
from botocore.client import ClientError

def create_table(session, dynamodb):
   
    # Create the DynamoDB table.
    table = dynamodb.create_table(
        TableName='Book',
        KeySchema=[
            {
                'AttributeName': 'id',
                'KeyType': 'HASH'  # Partition key
            },
            {
                'AttributeName': 'title',
                'KeyType': 'RANGE'  # Sort key
            }
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'id',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'title',
                'AttributeType': 'S'
            },
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 5,
            'WriteCapacityUnits': 5
        }
    )
    
    print("Table created successfully!")
    
def create_an_time(session, dynamodb):
    
    table = dynamodb.Table('Book')
    
    response = table.put_item(
        Item={
            'ISBN': '002',
            'Title': 'The Broken Windows',
            'Author': 'F. Scott Fitzgerald',
            'Year': 1940
        }
        )
    return response

def import_data_from_json(session, dynamodb):
    
    dynamodb_table_name = 'Book'
    
    with open('data.json', 'r', encoding='utf-8-sig') as f:
        data = json.load(f)
    
    for item in data:
        
        table = dynamodb.Table(dynamodb_table_name)

        # Add the data to the table
        try:
            response = table.put_item(Item=item)
            print(f"Book added to {dynamodb_table_name} table:", response)
        except ClientError as e:
            print(e.response['Error']['Message'])
    
    print('Successfully!')
    
def list_func():
    print('1.Create a table')
    print('2.Insert items')
    print('3.Import data from json')
    print('9.Help')


if __name__ == '__main__':

    # Initialize a session using Amazon DynamoDB
    session = boto3.session.Session(aws_access_key_id='', # add your key
                                aws_secret_access_key='', # add your key
                                region_name='') # add your region

    dynamodb = session.resource('dynamodb')
    
    choice = -1
    
    while(choice != 0):
        
        if(choice==-1):
            list_func()
        
        print('Your choice:')
        choice = int(input())
        
        if(choice==1):       
            create_table(session, dynamodb)
        if(choice==2):
            create_an_time(session, dynamodb)
        if(choice==3):
            import_data_from_json(session, dynamodb)
        if(choice==9):
            list_func()